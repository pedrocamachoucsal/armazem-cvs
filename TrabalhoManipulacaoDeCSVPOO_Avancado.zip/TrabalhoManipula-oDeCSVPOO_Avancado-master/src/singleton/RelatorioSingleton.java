package singleton;

import java.util.HashMap;
import java.util.Map;

/**
 * Gerenciador central do relatório final. Utiliza o padrão Singleton
 * para garantir uma única instância thread-safe que acumula os resultados.
 */
public class RelatorioSingleton {
    
    // Instância única da classe (volatile garante visibilidade entre threads)
    private static volatile RelatorioSingleton instance;

    // Variáveis para acumular os resultados das operações concorrentes
    private double valorTotalVendido = 0.0;
    private int quantidadeTotalItens = 0;
    private final Map<String, Integer> produtosQuantidadeMap = new HashMap<>();

    // Construtor privado para impedir instanciação externa
    private RelatorioSingleton() {}

    // Método estático público para obter a instância única (Double-Checked Locking)
    public static RelatorioSingleton getInstance() {
        if (instance == null) {
            synchronized (RelatorioSingleton.class) {
                if (instance == null) {
                    instance = new RelatorioSingleton();
                }
            }
        }
        return instance;
    }

    /**
     * Atualiza os dados do relatório de forma síncrona/thread-safe.
     */
    public synchronized void acumularDados(String produto, double valor, int quantidade) {
        this.valorTotalVendido += (valor * quantidade);
        this.quantidadeTotalItens += quantidade;
        
        // Atualiza o mapa de frequência do produto de forma segura
        this.produtosQuantidadeMap.put(produto, 
            this.produtosQuantidadeMap.getOrDefault(produto, 0) + quantidade);
    }

    /**
     * Exibe o relatório final consolidado no terminal.
     */
    public synchronized void exibirRelatorioFinal() {
        String produtoMaisVendido = "Nenhum";
        int maiorQuantidade = 0;

        // Encontra o produto mais vendido para o resumo
        for (Map.Entry<String, Integer> entry : produtosQuantidadeMap.entrySet()) {
            if (entry.getValue() > maiorQuantidade) {
                maiorQuantidade = entry.getValue();
                produtoMaisVendido = entry.getKey();
            }
        }

        // --- RENDERIZAÇÃO DO DASHBOARD NO TERMINAL ---
        System.out.println("\n###########################################################");
        System.out.println("┌─────────────────────────────────────────────────────────┐");
        System.out.println("│          DASHBOARD DE ANÁLISE DE VENDAS (CONCORRENTE)   │");
        System.out.println("└─────────────────────────────────────────────────────────┘");
        System.out.printf("  VALOR TOTAL VENDIDO : R$ %,.2f\n", valorTotalVendido);
        System.out.println("  TOTAL DE ITENS      : " + quantidadeTotalItens + " unidades");
        System.out.println("  PRODUTO LÍDER       : " + produtoMaisVendido + " (" + maiorQuantidade + " u)");
        System.out.println("###########################################################\n");
        System.out.println(" QUANTIDADE VENDIDA POR PRODUTO (GRÁFICO DE BARRAS):");
        System.out.println(" ───────────────────────────────────────────────────────────");

        // Configuração do tamanho máximo da barra do gráfico no console
        int tamanhoMaximoBarra = 30;

        for (Map.Entry<String, Integer> entry : produtosQuantidadeMap.entrySet()) {
            String produto = entry.getKey();
            int qtd = entry.getValue();
            
            // Calcula a proporção do produto em relação ao total de itens vendidos
            double percentual = (double) qtd / quantidadeTotalItens;
            int tamanhoBarra = (int) Math.round(percentual * tamanhoMaximoBarra);

            // Garante que se vendeu pelo menos 1, a barra terá tamanho mínimo de 1
            if (tamanhoBarra == 0 && qtd > 0) {
                tamanhoBarra = 1;
            }

            // Monta a barra de progresso visual
            StringBuilder barra = new StringBuilder();
            for (int i = 0; i < tamanhoMaximoBarra; i++) {
                if (i < tamanhoBarra) {
                    barra.append("█"); // Parte cheia
                } else {
                    barra.append("░"); // Parte vazia
                }
            }

            // Imprime a linha do gráfico formatada com alinhamento à esquerda (%-15s)
            System.out.printf(" %-15s | %s  %3d u  (%5.1f%%)\n", 
                    produto, barra.toString(), qtd, percentual * 100);
        }
        
        System.out.println(" ───────────────────────────────────────────────────────────");
        System.out.println(" [Status: Processamento Concorrente Concluído com Sucesso]\n");
    }
}